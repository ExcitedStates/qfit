#ifndef MY_MIQP_
#define MY_MIQP_
void MyMIQP(double** A, double* B, int n, double* s, double threshold);
#endif
